﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;

namespace UniversalRobotsConnect.Types
{
    public class OutputDoubleRegister
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public double Register0 { get; set; }
        public double Register1 { get; set; }
        public double Register2 { get; set; }
        public double Register3 { get; set; }
        public double Register4 { get; set; }
        public double Register5 { get; set; }
        public double Register6 { get; set; }
        public double Register7 { get; set; }
        public double Register8 { get; set; }
        public double Register9 { get; set; }
        public double Register10 { get; set; }
        public double Register11 { get; set; }
        public double Register12 { get; set; }
        public double Register13 { get; set; }
        public double Register14 { get; set; }
        public double Register15 { get; set; }
        public double Register16 { get; set; }
        public double Register17 { get; set; }
        public double Register18 { get; set; }
        public double Register19 { get; set; }
        public double Register20 { get; set; }
        public double Register21 { get; set; }
        public double Register22 { get; set; }
        public double Register23 { get; set; }
    }
}
