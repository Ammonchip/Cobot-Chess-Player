import URBasic 
import time

host = "10.224.1.115"   #E.g. a Universal Robot offline simulator, please adjust to match your IP
acc = 0.9
vel = 0.9

robotModle = URBasic.robotModel.RobotModel()
robot = URBasic.urScriptExt.UrScriptExt(host=host,robotModel=robotModle)

pose = robot.get_actual_tcp_pose()
print(pose)
